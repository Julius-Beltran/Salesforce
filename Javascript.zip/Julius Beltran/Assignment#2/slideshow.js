const imageList = ['./images/1.jpg','./images/2.jpg','./images/3.jpg','./images/4.jpg','./images/5.jpg'];
var count = 0;
function slideshow(){
    document.getElementById('slideImage').src = imageList[count];
    console.log(count);console.log(imageList.length);
    count++;
    if(count>=imageList.length){
        count = 0;
    }
    setTimeout("slideshow()",3000);
}