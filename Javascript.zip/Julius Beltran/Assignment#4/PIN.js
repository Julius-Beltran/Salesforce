function validateForm(){
    var NAME = document.getElementById('name').value;
    var DOB = document.getElementById("dateOfBirth").value;
    var PHONE = document.getElementById("phoneNumber").value;
    var PIN = "";
    if(NAME == "" || DOB == "" || PHONE == ""){
        document.getElementById("errorMessage").innerHTML='<div style="color:red;">Please fill-up all the field</div>';
        return false;
    } else{
        document.getElementById("errorMessage").innerHTML='';
    }    
    if(NAME.search(/[0-9]/) > -1){
        alert("Name should not contain numerals");
        return false;
    }    
    if(PHONE.search(/[a-z]/) > -1 || PHONE.search(/[A-Z]/) > -1){
        alert("Phone number should not contain characters");
        return false;
    }

    var nameVar = (NAME.substring(0, 4)).toUpperCase();
    var phoneVar = PHONE.slice(PHONE.length - 5);
    var BOD = new Date(DOB);
    console.log(BOD.getDay());
    if(BOD.getDate()<10){
        var dayVar = "0" + BOD.getDate();
    } else {
        var dayVar = BOD.getDate();
    }
    if(BOD.getMonth()+1<10){
        var monthVar = "0" + (BOD.getMonth()+1);
    } else {
        var monthVar = (BOD.getMonth()+1);
    }
    var yearVar = BOD.getFullYear().toString().slice(-2);
    PIN = nameVar+dayVar+monthVar+yearVar+phoneVar;


    document.getElementById("errorMessage").innerHTML='PIN: '+PIN;
    console.log(PIN);
    return false;
}