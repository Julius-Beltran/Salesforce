function storeSearch(){
    let x = document.getElementById("sInput")
}
